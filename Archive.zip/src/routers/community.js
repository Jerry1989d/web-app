
export const communityMap = [
    {
      path: '/login',
      name: 'login',
      meta:{
        title:'登录'
      },
        component: ()=> import('_v/login/index.vue'),
        
    },
    {
      path: '/home',
      name: 'home',
      meta:{
        title:'首页'
      },
        component: ()=> import('_v/home/index.vue')
    },
]