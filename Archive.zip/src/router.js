import Vue from 'vue'
import Router from 'vue-router'
import Container from './container/index'
import {communityMap} from './routers/community'
Vue.use(Router)
export const asyncRouterMap = [
    {
        path: '',
        meta: {
            title: '首页',
        },
        redirect: '/login',
        component: Container,
        children: communityMap
    }
]

const router = new Router({
    routes: asyncRouterMap
})
export default router