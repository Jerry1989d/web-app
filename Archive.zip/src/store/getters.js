export default {
    editAddress: state => state.editAddress,
    wechatInfo: state => state.wechatInfo,
    userInfo: state => state.userInfo,
    location: state => state.location,
    channels: state => state.channels
}