import {
    getToken,
    setToken,
    removeToken,
    getAccount,
    setAccount,
    removeAccount
} from '@/utils/authentication'
import {commonApi} from "../../api";

export default {
    state:{
        account: getAccount(),
        token: getToken()
    },
    mutations: {
        SET_TOKEN: (state, token) => {
            state.token = token
        },
        SET_ACCOUNT: (state, account) =>{
           state.account = account
        },
    },
    actions: {
        //全局登录方法
        Login({
                  commit
              }, data) {
            return new Promise(async (resolve, reject) => {
                let res = await commonApi(data,'login','post');
                if (res.retType === 1) {
                    let account = res.data;
                    console.log(account)
                    setAccount(account);
                    commit('SET_ACCOUNT', account);
                    setToken(account);
                    commit('SET_TOKEN', account.token);
                    resolve()
                }
            })
        },
        //全局退出登录方法
        Logout({
                   commit
               }) {
            removeToken();
            commit('SET_TOKEN', '');
            removeAccount();
            commit('SET_ACCOUNT', {});
        }

    }
}