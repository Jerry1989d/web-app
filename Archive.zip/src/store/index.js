import Vue from 'vue'
import Vuex from 'vuex'
import  getters from '@/store/getters'
import account from '@/store/modules/index'

Vue.use(Vuex)
//实例化vuex
export default new Vuex.Store({
    modules:{
        account
    },
    getters
})