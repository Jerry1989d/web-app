import Vue from 'vue'
import App from './App.vue'
import router from '@/router'
import tools from './utils/index'
import './style/index.scss'
import './plugins/extension'
import './plugins/vueExtension'
import store from '@/store/index'
import {getToken} from '@/utils/authentication'
/*
 @按需引入vant组件
  */
import {
  Field,
  Button,
} from 'vant'
Vue.use(Field).use(Button);

/*
 * @是否开启环境提示消息（此项可忽略）
 * */
Vue.config.productionTip = false;
/*
 * @挂载工具类到vue原型
 * */
Vue.prototype.tools = tools;
/*
 * @开发环境是否使用模拟数据
 * */
process.env.VUE_APP_MOCK === 'true' && import('@/utils/mock.js')

/*
 * @实例化vue
 * */
new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app');
/*
 * @动态改变页面标题
 * */
router.beforeEach((to, from, next) => {
  let userName = getToken();
  if(to.meta.title){
    document.title = to.meta.title
  }else if(to.name === 'login' && userName){
      next({path:'/login'})
  }
  next()
});


