import request from '../utils/request'
import api from './config'

/**
 * @name 全局api方法
 * @param data {Object} 为参数
 * @param method { string } 为请求连接(在config里配置)
 * @param requestType { string } 请求方式
 * **/
export function commonApi(data, method, requestType = 'get') {
    let link = api[method];
    let config = {
        url: link,
        method: requestType,
    }
    if (requestType === 'post') {
        config.data = data;
    } else {
        config.params = data;
    }
    return request(config)
}