/**
 * login 为传入 api 的key 
 * apiList为你的请求地址 
 * baseUr请在根目录.env文件配置
 * */

const apiList = {
    login:`/login`,

}

export default  apiList