<template>
  <div id="app">
    <router-view :key="key"></router-view>
  </div>
</template>
<script>
export default {
  name: 'app',
  data(){
    return{
    }
  },
  created(){
    //刷新页面 如果用户已经退出则跳转到登录页面
    if(!this.$store.state.account.token){
      this.$router.push('/login')
    }
  },
}
</script>

