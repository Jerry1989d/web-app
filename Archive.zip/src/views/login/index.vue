<template>
    <div class="container">
    <div class="form">
      <h3>登录</h3>
      <van-field v-model="form.userName" required label="用户名" placeholder="请输入用户名" />
      <van-field v-model="form.password"  required label="密 码" type="password" placeholder="请输入密码" />
      <van-button type="primary" @click='login'>登录</van-button>
    </div>
    </div>
</template>
<script>
import { Toast } from 'vant'
    export default {
        name: "loginWindow",
        data(){
            return {
              form: {
                userName: '',
                password: ''
              }
            }
        },
        methods:{
          login(){
            if(this.form.userName && this.form.password){
              this.$store.dispatch('Login',{userName:'jerry',password:'123456'})
                .then(()=>{
                    this.$router.push('/home')
                })
            }else{
              Toast('亲，要输入用户名和密码哦！')
            }
          }
        },
    }
</script>
<style scoped lang="scss">
.container{
   text-align: center;
  .form{
  display: inline-block;
  height: 360px;
  margin-top: 20%;
  button{
    width: 100%;
  }
}
}
</style>