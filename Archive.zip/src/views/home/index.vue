<template>
  <div class="container">
    恭喜你登录成功拉！
    <van-button @click="logOut">退出登录</van-button>
  </div>
</template>
<script>
import { button } from 'vant'
export default {
  name:'home',
  data(){
    return{

    }
  },
  methods:{
    logOut(){
      this.$store.dispatch('Logout')
                .then(()=>{
                    this.$router.push('/login')
                })
    }
  }
}
</script>
<style lang="scss" scoped>
 .container{
   padding: 10px;
   text-align: center;
   button{
     display: block;
     margin:20px auto 0 auto;
   }
 }
</style>

